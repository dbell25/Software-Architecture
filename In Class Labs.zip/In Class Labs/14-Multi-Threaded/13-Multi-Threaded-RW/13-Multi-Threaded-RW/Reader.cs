﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Multi_Threaded_RW
{

    // interface for Files that can be read:
    public interface Reader { string readLine(); }
}
