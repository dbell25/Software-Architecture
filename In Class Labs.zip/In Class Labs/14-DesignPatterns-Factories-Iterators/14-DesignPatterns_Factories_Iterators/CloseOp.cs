﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns_Factories_Iterators
{
    // delegate defining the data type of a close-the-file method:
    public delegate void CloseOp();
}
