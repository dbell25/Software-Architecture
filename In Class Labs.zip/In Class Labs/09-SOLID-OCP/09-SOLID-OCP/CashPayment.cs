﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_SOLID_OCP
{
    class CashPayment : IMethodPayment
    {
        public bool ProcessedPayment(double amount)
        {
            return CashPayment.processPayment(amount);
        }

        public static bool processPayment(double amount)
        {
            Console.WriteLine("Processing payment with cash in IMethodPayment");
            return true;
        }
    }
}
