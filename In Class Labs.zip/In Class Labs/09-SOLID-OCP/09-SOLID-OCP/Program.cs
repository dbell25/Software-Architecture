﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static _09_SOLID_OCP.Program;

namespace _09_SOLID_OCP
{
    public delegate bool PaymentMethod(double amount);
    class Program
    {
        static void Main(string[] args)
        {
            OrderOCP anOrder = new OrderOCP(1, "Headphones", 35.09);
            Console.WriteLine("**** NAIVE ****");
            Console.WriteLine();
            Console.WriteLine("Select method of payment: ");
            Console.WriteLine("1. Cash");
            Console.WriteLine("2. Credit Card");
            int op = Convert.ToInt32(Console.ReadLine());

            switch (op)
            {
                case 1: Console.WriteLine("Processing the order with cash"); break;
                case 2: Console.WriteLine("Processing the order with credit card"); break;
                default: Console.WriteLine("Method payment not accepted"); break;
            }
            Console.ReadLine();
        }
    }
}
