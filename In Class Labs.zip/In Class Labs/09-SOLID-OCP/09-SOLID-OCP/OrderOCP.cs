﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_SOLID_OCP
{
    class OrderOCP
    {
        private int _ID;
        private string _item;
        private double _amount;
        private bool _paid;

        public OrderOCP(int ID, string name, double amount)
        {
            this._ID = ID;
            this._item = name;
            this._amount = amount;
        }

        public void ProcessOrder(PaymentMethod pm)
        {
            bool success = pm(_amount);
            _paid = true;
        }
    }
}