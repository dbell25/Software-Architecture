﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09_SOLID_OCP
{
    class VisaPayment : IMethodPayment
    {
        public bool ProcessedPayment(double amount)
        {
            Console.WriteLine("Processing Visa card payment in IMethodPayment");
            return true;
        }
    }
}
