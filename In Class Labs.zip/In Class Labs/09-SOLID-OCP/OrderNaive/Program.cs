﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderNaive
{
    class Program
    {
        static void Main(string[] args)
        {
            order anOrder = new order(1, "Headphones", 35.09);
            Console.WriteLine("**** NAIVE ****");
            Console.WriteLine();
            Console.WriteLine("Select method of payment: ");
            Console.WriteLine("1. Cash");
            Console.WriteLine("2. Credit Card");
            int op = Convert.ToInt32(Console.ReadLine());

            anOrder.ProcessOrder(op);
            Console.ReadLine();
        }
    }
}
