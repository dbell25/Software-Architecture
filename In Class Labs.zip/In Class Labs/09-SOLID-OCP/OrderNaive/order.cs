﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderNaive
{
    class order
    {
        private int _ID;
        private string _item;
        private double _amount;
        private bool _paid;

        public order(int ID, string name, double amount)
        {
            this._ID = ID;
            this._item = name;
            this._amount = amount;
        }

        public void ProcessOrder(int method)
        {
            switch (method)
            {
                case 1: Console.WriteLine("Processing the order with cash"); break;
                case 2: Console.WriteLine("Processing the order with credit card"); break;
                default: Console.WriteLine("Method payment not accepted"); break;
            }
            _paid = true;
        }
    }
}
