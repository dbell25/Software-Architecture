﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_SOLID_LSP
{
    public class Shape
    {
        private ShapeType type;

        public Shape(ShapeType t)
        {
            type = t;
        }

        public void DrawShape()
        {
            if (type == ShapeType.circle)
            {
                ((Circle)this).Draw();
            }
            else if (type == ShapeType.square)
            {
                ((Square)this).Draw();
            }
        }
    }


    public class Circle : Shape
    {
        private Point center;
        private double radius;

        public Circle() : base(ShapeType.circle) { }
        public void Draw()
        {
            Console.WriteLine("Drawing a Circle");
            // Draw the circle
        }
    }

    public class Square : Shape
    {
        private Point topLeft;
        private double side;

        public Square() : base(ShapeType.square) { }
        public void Draw()
        {
            Console.WriteLine("Drawing a Square");
            // Draw the square
        }
    }
}
