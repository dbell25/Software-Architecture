﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_SOLID_LSP
{
    struct Point
    {
        double x;
        double y;
    }

    public enum ShapeType {square, circle };

    class Program
    {
        static void Main(string[] args)
        {
            List<Shape> shapes = new List<Shape>();
            shapes.Add(new Circle());
            shapes.Add(new Square());
            shapes.Add(new Circle());

            foreach (Shape s in shapes)
            {
                s.DrawShape();
            }

        }
    }
}
