﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSP_Compliant
{
    struct Point
    {
        double x;
        double y;
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<ShapeLSP> shapes = new List<ShapeLSP>();
            shapes.Add(new ICircle(0));
            shapes.Add(new ISquare(0));

            foreach (ShapeLSP k in shapes)
            {
                k.Draw();
            }
        }
    }
}
