﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSP_Compliant
{
    public interface ShapeLSP
    {
        void Draw();
    }

    public class ICircle : ShapeLSP
    {
        private Point center;
        private double radius;

        public ICircle(double j)
        {
            Console.WriteLine("Circle Made");
        }

        public void Draw()
        {
            Console.WriteLine("Drawing a Circle.");
        }
    }


    public class ISquare : ShapeLSP
    {
        private Point topLeft;
        private double side;

        public ISquare(double j)
        {
            Console.WriteLine("Circle Made");
        }

        public void Draw()
        {
            Console.WriteLine("Drawing a Circle.");
        }
    }
}
