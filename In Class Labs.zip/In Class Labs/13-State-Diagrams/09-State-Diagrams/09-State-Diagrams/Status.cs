﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace State_Diagrams
{
    // states of the number-guessing game
    public enum Status { Start, HaveMN, Win, Lose };
}
